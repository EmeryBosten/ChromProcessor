import numpy as np
from typing import List, Any

from . import Chromatogram

from ..peak_models import BiGaussian

#functions for peak tracking
from ..peak_tracking import SimMeasurementMS, SimMeasurementUV, chosenPairMS, chosenPairUV

class Chromatograms:
    """  """
    chromatograms: List[Chromatogram]
    """chromatograms to process"""
    MS: Any
    """MS or UV data"""
    preprocessing: Any
    """indicate if preprocess chroms """

    def __init__(self, chromatograms: List, MS: Any):
        self.chromatograms = chromatograms
        self.MS = MS

    def track_peaks(self, preprocessing=False):
        if preprocessing:
            preprocessed_chromatograms = []
            for chromatogram in self.chromatograms:
                chromatogram.remove_blank()
                chromatogram.correct_baseline()
                chromatogram.remove_noise()
                preprocessed_chromatograms.append(chromatogram)

            self.chromatograms = preprocessed_chromatograms

        # peak detection and deconvolution
        multi_peaks = []
        for chromatogram in self.chromatograms:
            chromatogram.detect_peaks()
            chromatogram.deconvolve_peaks(BiGaussian())
            multi_peaks.append(chromatogram.peaks)

        # peak tracking
        # Reshape chromatogram metrics
        Specs = []
        Peak_heights = []
        relative_rts = []
        rts = []

        for chrom_idx in range(len(multi_peaks)):
            chrom_Specs = []
            chrom_Peak_heights = []
            chrom_relative_rts = []
            chrom_rts = []
            for idx, peak in enumerate(multi_peaks[chrom_idx]):
                for j in range(multi_peaks[chrom_idx][idx].concentrations.shape[0]):
                    chrom_Specs.append(multi_peaks[chrom_idx][idx].spectra[j])
                    chrom_Peak_heights.append(
                        self.chromatograms[chrom_idx].chrom_1D[multi_peaks[chrom_idx][idx].all_maxima[j]])
                    chrom_relative_rts.append(
                        (self.chromatograms[chrom_idx].time[multi_peaks[chrom_idx][idx].all_maxima[j]]) /
                        self.chromatograms[chrom_idx].time[-1])
                    chrom_rts.append(
                        (self.chromatograms[chrom_idx].time[multi_peaks[chrom_idx][idx].all_maxima[j]]))

                    Specs.append(chrom_Specs)
                    Peak_heights.append(chrom_Peak_heights)
                    relative_rts.append(chrom_relative_rts)
                    rts.append(chrom_rts)

            # set reference chromatogram
            numPeaks = [len(sublist) for sublist in relative_rts]
            MaxNumPeaks = np.max(numPeaks)
            indMaxNumPeaks = np.argmax(numPeaks)
            num_chroms = len(numPeaks)

            # Track peaks compared to reference chromatogram
            Tracks = []
            i = 0
            j = 0
            while i <= num_chroms - 1:
                if i == indMaxNumPeaks:
                    i = i + 1
                if self.MS:
                    [heightSim, countMS, posSim] = SimMeasurementMS(MaxNumPeaks, numPeaks[i],
                                                                    Peak_heights[indMaxNumPeaks], Peak_heights[i],
                                                                    Specs[indMaxNumPeaks], Specs[i],
                                                                    relative_rts[indMaxNumPeaks], relative_rts[i])
                    [pairs, _] = chosenPairMS(heightSim, countMS, posSim)
                    Tracks.append(pairs)
                    i = i + 1
                    j = j + 1
                else:
                    [simUV, heightSim, posSim] = SimMeasurementUV(MaxNumPeaks, numPeaks[i],
                                                                  Peak_heights[indMaxNumPeaks], Specs[indMaxNumPeaks],
                                                                  Specs[i], Peak_heights[i],
                                                                  relative_rts[indMaxNumPeaks], relative_rts[i])
                    [pairs, _] = chosenPairUV(simUV, heightSim, posSim)
                    Tracks.append(pairs)
                    i = i + 1
                    j = j + 1

            # Create Retention Time Table
            # Convert numPeaks to numpy array
            numPeaks = np.asarray(numPeaks)

            # Create retention timetable
            tab = np.zeros((numPeaks.max(), len(numPeaks)), dtype=int)
            tab[:, 0] = np.arange(1, numPeaks.max() + 1)

            # Retention Time Table -> list of lists
            summaryPeaks = [[None for _ in range(len(numPeaks))]
                            for _ in range(numPeaks.max())]

            MaxNumPeaks = numPeaks.max()
            indMaxNumPeaks = np.argmax(numPeaks)

            # Fill first column of summaryPeaks
            for i in range(MaxNumPeaks):
                summaryPeaks[i][0] = rts[indMaxNumPeaks][i]

            # Main loop
            for i in range(1, len(numPeaks)):
                # Tracks[i-1] is assumed to be a 2D array
                for j in range(Tracks[i - 1].shape[0]):
                    k = Tracks[i - 1][j, 0] - 1
                    tab[k, i] = Tracks[i - 1][j, 1]
                    summaryPeaks[k][i] = rts[i][tab[k, i] - 1]
            return summaryPeaks
        return None
