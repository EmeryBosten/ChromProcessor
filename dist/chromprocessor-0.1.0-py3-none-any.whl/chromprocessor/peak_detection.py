# function for automated peak detection

import numpy as np

def findMin(deriv2, y, noise_thresh, height_ratio, minimum_depth):
    """
    Function to find peak apex based on minima in second derivative

    Parameters
    ----------
    deriv2 : array_like
        Second derivative of the signal
    y : array_like
        Original signal
    noise_thresh : float
        Noise threshold multiplier
    height_ratio : float
        Height ratio constraint
    minimum_depth : float
        Minimum depth factor for derivative minima

    Returns
    -------
    apex_loc : np.ndarray
        Indices of detected minima
    """

    deriv2 = np.asarray(deriv2, dtype=float)
    y = np.asarray(y, dtype=float)

    # normalization (between -1 and 1)
    max_deriv2 = np.max(np.abs(deriv2))
    deriv2 = deriv2 / max_deriv2

    k = 1.4826
    max_y_noise = k * np.median(np.abs(y - np.median(y)))  # noise estimate original signal
    max_y = np.max(y)  # highest peak in original signal
    max_deriv2_noise = k * np.median(np.abs(deriv2 - np.median(deriv2)))  # noise estimate second derivative

    apex_loc = []

    for i in range(3, len(deriv2) - 3):
        cond1 = (deriv2[i - 1] > deriv2[i] and deriv2[i - 2] > deriv2[i] and deriv2[i - 3] > deriv2[i] and
                 deriv2[i + 1] > deriv2[i] and deriv2[i + 2] > deriv2[i] and deriv2[i + 3] > deriv2[
                     i])  # identifying minimas

        cond2 = deriv2[i] < -minimum_depth and deriv2[i] < - abs(
            noise_thresh * max_deriv2_noise)  # minima is smaller than defined threshold and deriv2 noise thresh

        cond3 = y[i] > noise_thresh * max_y_noise and y[
            i] > max_y / height_ratio  # peak is bigger than defined thresh based on highest peak and noise thresh

        if cond1 and cond2 and cond3:
            idx = i
            for j in range(1, 11):
                if (y[idx + j] > y[idx + j + 1]) and (y[idx + j] > y[idx + j - 1]):
                    idx += j
                if (y[idx - j] > y[idx - j + 1]) and (y[idx - j] > y[idx - j - 1]):
                    idx -= j
            apex_loc.append(idx)

    return np.unique(apex_loc)


def peakStartEnd(y, apex):
    """
    Function to find start and end of peaks
    :param y:  1D chromatogram
    :param apex: apex locations of peaks
    :return:
    startpoint = start point of peaks
    endpoint = end point of peaks

    """

    e = 0.05 # very arbitrary threshold

    startpoint = []
    endpoint = []

    max_y = np.max(np.abs(y))
    y = y / max_y

    I = np.extract(y < min(y) + e, np.arange(len(y)))

    for i in range(len(apex)):
        S = np.extract(I < apex[i], np.arange(len(I)))
        s = I[S[-1]]
        startpoint.append(s)
        G = np.extract(I > apex[i], np.arange(len(I)))
        g = I[G[1]]
        endpoint.append(g)

    return startpoint, endpoint